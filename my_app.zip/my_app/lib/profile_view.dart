import 'package:flutter/material.dart';


class ProfileView extends StatelessWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text ("My first App",style: TextStyle(color: Colors.white,),),
      ),
      body: Column(children: [
      Container(
        color: Colors.grey,
        width: 100,
        height: 100,
        child: const Text("1",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      )
      ,
      
      Container(child:  Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [ 
        Container(
        color: Colors.red,
        width: 100,
        height: 100,
        child: const Text("2",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.green,
        width: 100,
        height: 100,
        child: const Text("2",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),],),)
      ,
     
     Container(child:  Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [ 
        Container(
        color: Colors.red,
        width: 100,
        height: 100,
        child: const Text("3",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.green,
        width: 100,
        height: 100,
        child: const Text("3",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.grey,
        width: 100,
        height: 100,
        child: const Text("3",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      )],),)
      ,

      Container(child:  Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [ 
        Container(
        color: Colors.red,
        width: 100,
        height: 100,
        child: const Text("4",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.green,
        width: 100,
        height: 100,
        child: const Text("4",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.grey,
        width: 100,
        height: 100,
        child: const Text("4",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.indigo,
        width: 100,
        height: 100,
        child: const Text ("4",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),],),),
      
      Container(child:  Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [ 
        Container(
        color: Colors.red,
        width: 100,
        height: 100,
        child: const Text("5",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.green,
        width: 100,
        height: 100,
        child: const Text("5",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.grey,
        width: 100,
        height: 100,
        child: const Text("5",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.indigo,
        width: 100,
        height: 100,
        child: const Text("5",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),
      Container(
        color: Colors.blue,
        width: 100,
        height: 100,
        child: const Text("5",style: TextStyle(color: Colors.white, fontSize: 85),textAlign: TextAlign.center),
      ),],),),
      
     ],)
    );
  }
}
  
