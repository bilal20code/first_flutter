import 'package:flutter/material.dart';

class First extends StatelessWidget {
  const First({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "My First App",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              color: Colors.grey,
              width: 100,
              height: 100,
              child: const Text(
                "1",
                style: TextStyle(color: Colors.white, fontSize: 85),
                textAlign: TextAlign.center,
              ),
            ),
            SizedBox(height: 10),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    color: Colors.red,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "2",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.green,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "2",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.blue,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "2",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.orange,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "2",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.brown,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "2",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.black,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "2",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    color: Colors.red,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "3",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.green,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "3",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.grey,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "3",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    color: Colors.red,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "4",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.green,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "4",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.grey,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "4",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.indigo,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "4",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    color: Colors.red,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "5",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.green,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "5",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.grey,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "5",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.indigo,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "5",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Container(
                    color: Colors.blue,
                    width: 100,
                    height: 100,
                    child: const Text(
                      "5",
                      style: TextStyle(color: Colors.white, fontSize: 85),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: First(),
  ));
}
